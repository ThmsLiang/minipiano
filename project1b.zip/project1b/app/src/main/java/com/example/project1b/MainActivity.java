package com.example.project1b;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;


/*
code regarding SoundPool is partially taken from https://androiddvlpr.com/using-android-soundpool-build-your-own-android-piano-app/
 */
public class MainActivity extends AppCompatActivity {
    private int c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int a;
    private int b;
    private int cs;
    private int ds;
    private int fs;
    private int gs;
    private int as;
    private SoundPool soundPool;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC,0);
        c = soundPool.load(getApplicationContext(), R.raw.c,1);
        d = soundPool.load(getApplicationContext(), R.raw.d,1);
        e = soundPool.load(getApplicationContext(), R.raw.e,1);
        f = soundPool.load(getApplicationContext(), R.raw.f,1);
        g = soundPool.load(getApplicationContext(), R.raw.g,1);
        a = soundPool.load(getApplicationContext(), R.raw.a,1);
        b = soundPool.load(getApplicationContext(), R.raw.b,1);
        cs = soundPool.load(getApplicationContext(), R.raw.cs,1);
        ds = soundPool.load(getApplicationContext(), R.raw.bb,1);
        fs = soundPool.load(getApplicationContext(), R.raw.fs,1);
        gs = soundPool.load(getApplicationContext(), R.raw.gs,1);
        as = soundPool.load(getApplicationContext(), R.raw.eb,1);
    }

    public void playC(View view){
        soundPool.play(c,1,1,1,0,1);
    }

    public void playD(View view){
        soundPool.play(d,1,1,1,0,1);
    }

    public void playE(View view){
        soundPool.play(e,1,1,1,0,1);
    }

    public void playF(View view){
        soundPool.play(f,1,1,1,0,1);
    }

    public void playG(View view){
        soundPool.play(g,1,1,1,0,1);
    }

    public void playA(View view){
        soundPool.play(a,1,1,1,0,1);
    }

    public void playB(View view){
        soundPool.play(b,1,1,1,0,1);
    }

    public void playCS(View view){
        soundPool.play(cs,1,1,1,0,1);
    }

    public void playDS(View view){
        soundPool.play(ds,1,1,1,0,1);
    }

    public void playFS(View view){
        soundPool.play(fs,1,1,1,0,1);
    }

    public void playGS(View view){
        soundPool.play(gs,1,1,1,0,1);
    }

    public void playAS(View view){
        soundPool.play(as,1,1,1,0,1);
    }
}
